#include "Game.h";

//Loads the map and loads the Hand or topBoard
Game::Game() {
	mapLoader.load("Map.txt");
	players = new list<Player*>();
	deck = new Deck();
	topBoard = deck->topBoardGenetor(*deck);
}

//When buying a card, it uses the exchange function for said player
void Game::buyCard() {
	deck->exchange(topBoard, *deck, *players->front());
	endTurn();
	Notify();
}

//When the player's turn has ended, they are put to the back of the list
void Game::endTurn() {
	players->push_back(players->front());
	players->pop_front();
}

//Adds players to game
void Game::addPlayer(Player& p) {
	players->push_back(&p);
}

//Deconstructs game
Game::~Game() {
	delete deck;
	deck = nullptr;
	list<Player*>::iterator i;
	for (i = (*players).begin(); i != (*players).end(); ++i) {
		delete *i;
		*i = nullptr;
	}
	delete players;
	players = nullptr;
	vector<Cards*>::iterator x;
	for (x = topBoard.begin(); x != topBoard.end(); ++x) {
		delete *x;
		*x = nullptr;
	}
	topBoard.clear();
}