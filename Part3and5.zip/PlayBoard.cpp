#include "PlayBoard.h";

PlayBoard::PlayBoard() {

};

PlayBoard::PlayBoard(Game* g) {
	game = g;
	game->Attach(this);
}

PlayBoard::~PlayBoard() {
	game->Detach(this);
	game = nullptr;
}

void PlayBoard::Update() {
	display();
}

//displays current amount of coins of said player
void PlayBoard::display() {
	cout << game->getPlayer().getName() << ", you have " << game->getPlayer().getCoins() << endl;
}