#include "Game.h";
#include "PlayBoardController.h";

//copied the observer pattern in MVC and Observer lecture
int main(void) {
	Game* model = new Game();
	PlayBoard* view = new PlayBoard(model);
	PlayBoardController* controller = new PlayBoardController(model, view);
	Player* player1 = new Player("Bob", 2);
	Player* player2 = new Player("Sal", 2);
	model->addPlayer(*player1);
	model->addPlayer(*player2);

	//main game loop
	controller->turn();
	delete controller;
	controller = nullptr;
	delete view;
	view = nullptr;
	delete model;
	model = nullptr;
	player1 = nullptr;
	player2 = nullptr;

	return 0;
}