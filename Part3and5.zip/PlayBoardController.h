#pragma once
#include "PlayBoard.h";

class PlayBoardController {
private:
	Game* game;
	PlayBoard* playboard;
public:
	PlayBoardController(Game* game, PlayBoard* playboard);
	~PlayBoardController();
	void turn();
};