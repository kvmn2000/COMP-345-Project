#pragma once

#include "Map.h"
#include "Cards.h"
#include "BidingFacility.h"

#include <iostream>
#include <string>
#include <vector>

using namespace std;

//declaring classes from other parts

class Player {

public:
    //below are the constructors 
    Player() = default;
    Player(string name);
    Player(string name, int amountOfPlayer);
    Player(const Player& copy);
    ~Player();
    Player& operator=(const Player& copy);
    friend ostream& operator << (ostream& out, const Player& copy);
    friend istream& operator >> (istream& in, Player& copy);


    //payCoin method
    bool payCoin(int cost);

    //other gameplay methods
    void placeNewArmies();
    void moveArmies();
    void moveOverLand();
    void buildCity();
    void destroyArmy();
    bool ignore();
    void andOrAction();
    void takeAction();

    //below are the accessors
    int getArmies() const;
    int getCoins() const;
    int getCities() const;
    string getName() const;
    int getId() const;


    //vector<Cards*> getGameHand() const;
    BidingFacility* getBidingFacility();

    //below are the Mutators
    void setArmies(int armies);
    void setCoins(int coins);
    void setCities(int cities);
    void setName(string name);
    void setId(int i);

    //our private constructors
private:

    int id;
    int coins;
    int armies;
    int cities;
    string name;
    BidingFacility* bidingFacility;


};