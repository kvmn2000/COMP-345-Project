#include "PlayBoardController.h";

PlayBoardController::PlayBoardController(Game* g, PlayBoard* p){
	game = g;
	playboard = p;
}

PlayBoardController::~PlayBoardController() {
	game = nullptr;
	playboard = nullptr;
}

//The main game loop
void PlayBoardController::turn() {
	while (true) {
		int command;
		cout << game->getPlayer().getName() << "'s Turn." << endl;
		cout << "1.Buy a card" << endl;
		cout << "2.Exit" << endl;
		cin >> command;
		switch (command) {
		case 1:
			game->buyCard();
			break;
		case 2:
			return;
		}
	}
}