#include "Observer.h"

Observer::Observer() {

};

Observer::~Observer() {

};