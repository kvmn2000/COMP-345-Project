#pragma once
#include "Map.h";
#include "Player.h";
#include "Subject.h";
#include "MapLoader.h"
#include "Cards.h";
using namespace std;

class Game : public Subject{
public:
	Game();
	~Game();
	void buyCard();
	void endTurn();
	void addPlayer(Player& p);
	Player& getPlayer() { return *(players->front()); };
private:
	MapLoader mapLoader;
	list<Player*>* players;
	Deck* deck;
	vector<Cards*> topBoard;
};