#pragma once
#include "Observer.h";
#include "Game.h";
using namespace std;

class PlayBoard : public Observer {
public:
	PlayBoard();
	PlayBoard(Game* g);
	~PlayBoard();
	void Update();
	void display();
private:
	Game* game;
};