#pragma once

#include "Map.h"
#include "Cards.h"
#include "BidingFacility.h"

#include <iostream>
#include <string>
#include <vector>

#define _DEBUG
#ifdef _DEBUG
#define new new( _NORMAL_BLOCK , __FILE__ , __LINE__ )
#endif

using namespace std;


struct Score {
    int *continentScore;
    int *regionScore;
    int *goodScore;
};

//declaring classes from other parts
class Player 
{

public:
    //below are the constructors 
    Player() = default;
    Player(string name);
    Player(int playerId, string playerName);
    Player(string name, int amountOfPlayer);
    Player(const Player& copy);
    ~Player();
    Player& operator=(const Player& copy);
    friend ostream& operator << (ostream& out, const Player& copy);
    friend istream& operator >> (istream& in, Player& copy);


    //payCoin method
    bool payCoin(int cost);

    int getArmies();
    int *flops;
    int getCoins();
    int getCities();
    string getName();
    int getId();
    Score *score;
    int getTotalScore();
    int *tokens;
    int age;
    int hand;
    vector<countryValue> *citiesIn;
    vector<countryValue> *armiesIn;
    

    //other gameplay methods
    typedef pair<Country*, int> countryValue;
    bool PlaceNewArmies(int armiesNum, Country *country, bool forceAdd);
    bool MoveArmies(int armiesNum, Country *to, Country *from);
    bool MoveOverLand(int armiesNum, Country *to, Country *from);
    bool MoveOverWater(int armiesNum, Country *to, Country *from);
    bool BuildCity(Country *country);
    bool DestroyArmy(Country *country, Player *player);
  
    void andOrAction();
    void takeAction();
    pair<Country*, int>* getArmiesInCountry(Country *country);
    pair<Country*, int>* getCitiesInCountry(Country *country);
    Player(Map *map, string name, int flopNum, int tokenNum, int armyNum);



    //vector<Cards*> getGameHand() const;
   BidingFacility* getBidingFacility();

    //below are the Mutators
    void setArmies(int armies);
    void setCoins(int coins);
    void setCities(int cities);
    void setName(string name);
    void setId(int i);
    void setFlops(int flop);
    void armyDestroyed(Country* country);
    void computeTotalGoodScore();
    void setTokens(int token);
    void printGoods();
    void display();

    //our private constructors
private:

    int id;
    int coins;
    int armies;
    int cities;
    string name;
    //vector <Country*> countryOwned;
    //vector <Cards*> gameHand;
   BidingFacility* bidingFacility;

};