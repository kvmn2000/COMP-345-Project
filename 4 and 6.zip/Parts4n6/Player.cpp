#include "Player.h"
#include "Map.h"

#include <string>
#include <iostream>

Player::Player(Map *map, string playerName, int flopNum, int tokenNum, int armyNum) {
    flops = new int(flopNum);
    tokens = new int(tokenNum);
    armies = new int(armyNum);
    name = new string(playerName);

    citiesIn = new vector<countryValue>;
    for (auto country : *(map->countries)) {
        citiesIn->push_back(make_pair(country.first, 0));
    }

    armiesIn = new vector<countryValue>;
    for (auto country : *(map->countries)) {
        armiesIn->push_back(make_pair(country.first, 0));
    }

    this->map = map;

    bidding = new BiddingFacility(tokens);
    hand = new vector<Card*>;

    age = new int(0);
    score = new Score();
    score->continentScore = new int(0);
    score->regionScore = new int(0);
    score->goodScore = new int(0);


}

Player::Player(int playerId, string playerName)
{
    id = playerId;
    name = playerName;
}

//default constructor with parameter
Player::Player(string playerName)
{
    name = playerName;
    id = 0;
    cities = 0;
    armies = 0;
    coins = 0;
    bidingFacility = new BidingFacility(playerName);

}

//default constructor with number of players.
Player::Player(string playerName, int numOfPlayers)
{
    name = playerName;
    id = 0;
    cities = 0;
    armies = 0;
   // bidingFacility = new BidingFacility(playerName);

    //Number of players decides how many coins they will recieve. 2 players = 14 coins, 3=11 coins and so on.
    switch (numOfPlayers)
    {
    case 2:
        Player::coins = 14;
        break;
    case 3:
        Player::coins = 11;
        break;
    case 4:
        Player::coins = 9;
        break;
    case 5:
        Player::coins = 8;
        break;
    }

}
//Copy Constructor
Player::Player(const Player& copy) {

}



Player::~Player() {

   cout << endl << "---------- DELETING PLAYER "<<id<<" -----------" << endl;
   delete bidingFacility;
   bidingFacility = NULL;
}

Player& Player::operator=(const Player& copy)
{
    cout << "Creating a Player copy:" << endl;
    return *(new Player(copy));
}

ostream& operator<<(ostream& out, const Player& copy)
{
    out << "Player name is : " << copy.name << endl;
    return out;
}

istream& operator>>(istream& in, Player& copy)
{
    cout << "Input Player name: ";
    in >> copy.name;
    return in;
}


//below are the accessors

int Player::getArmies()
{ 
    return armies; 
}

int Player::getCoins()
{ return coins; 
}

int Player::getCities() 
{ 
    return cities;
}

string Player::getName()
{
    return name;
}

int Player::getId() 
{ 
    return id; 
}


//std::vector<Cards*> *Player::getGameHand() const { return gameHand; }

BidingFacility* Player::getBidingFacility() {
    return bidingFacility;
}


//below are the Mutators
void Player::setId(int id) { this->id = id; }

void Player::setArmies(int armies) { this->armies = armies; }

void Player::setCoins(int coins) { this->coins = coins; }

void Player::setCities(int cities) { this->cities = cities; }

void Player::setName(std::string name) { this->name = name; }

void Player::setFlops(int flop) { *flops = flop;}

void Player::setTokens(int token) {*tokens = token;}

void Player::setArmies(int army) {armies = army;}


//Here is the PayCoin method. Using if else, we can determine the purchess succession. 
bool Player::payCoin(int cost)
{
    if (coins < cost) {
        std::cout << "INSUFFICIENT FUNDS" << "\n";
        return false;
    }
    else {
        setCoins(coins - cost);
        std::cout << "Success!!!!! " << name << ", you have " << coins << " coins left." << "\n" << "\n";
        return true;
    }
}

int Player::getTotalScore() {
    return *score->continentScore + *score->regionScore + *score->goodScore;
}


// Place new armies method
bool Player::PlaceNewArmies(int armiesNum, Country *country, bool forceAdd) {

    if (!forceAdd) {
        if (*armies < armiesNum) {
            cout << "Insufficient armies to place." << endl;
            return false;
        }
        countryValue *cityIn = getCitiesInCountry(country);
        if (cityIn->first == country) {
            if (cityIn->second <= 0 && country != map->startingRegion) {
                cout << "No cities available here. You Cannot place armies." << endl;
                return false;
            }
        }
        *armies -= armiesNum;
    }

    countryValue *armyIn = getArmiesInCountry(country);
    armyIn->second+=armiesNum;

    cout << "Placed " << armiesNum << " new armies in " << *(country->name) << endl;
    return true;

}

// Build City Method
bool Player::BuildCity(Country *country) {
    if(*flops < 1) {
        cout << "INSUFFICIENT." << endl;
        return false;
    }

    countryValue *armyIn = getArmiesInCountry(country);

    if (armyIn->second > 0) {
        *flops-=1;
        countryValue *cityIn = getCitiesInCountry(country);
        cityIn->second++;
        cout << "You can build in " << *(country->name) << endl;
        return true;
    }

    else {
        cout << "Armies NEEDED, to build cities!." << endl;
    }

    return false;
}

//MoveArmies Method
bool Player::MoveArmies(int armiesNum, Country *to, Country *from) {
    countryValue *armyInTo = getArmiesInCountry(to);
    countryValue *armyInFrom = getArmiesInCountry(from);

    if (map->isAdjacent(to, from)==-1) {
        cout << *(to->name) << " and " << *(from->name) << " are not adjacent." << endl;
        return false;
    }

    if (armyInFrom->second < armiesNum) {
        cout << "Insufficient armies to move." << endl;
        return false; 

    } else {
        armyInTo->second+= armiesNum;
        armyInFrom->second-=armiesNum;
        cout << "Success! Moved " << armiesNum << " armies from " << *(from->name) << " to " << *(to->name) << endl;
        return true;
    }

}
//Move over land method
bool Player::MoveOverLand(int armiesNum, Country *to, Country *from) {

    int adjacency = map->isAdjacent(to, from);
    if (adjacency == -1) {
        cout << *(to->name) << " and " << *(from->name) << " are not adjacent." << endl;
        return false;
    }
    if (adjacency == 1 ) {
        cout << "Hey!! You may only move from " << *(from->name) << " to " << *(to->name) << " by the water side." << endl;
        return false;
    }

    return MoveArmies(armiesNum, to, from);

}
//Move Over Water Method
bool Player::MoveOverWater(int armiesNum, Country *to, Country *from) {

    int adjacency = map->isAdjacent(to, from);
    if (adjacency == -1) {
        cout << *(to->name) << " and " << *(from->name) << " are not adjacent." << endl;
        return false;
    }
    if (adjacency == 0 ) {
        cout << "Hey!! You can only move from " << *(from->name) << " to " << *(to->name) << " by the land side." << endl;
        return false;
    }

    return MoveArmies(armiesNum, to, from);

}

//below is the method that enables the player to destroy the army of an opponent
bool Player::DestroyArmy(Country *country, Player *player) {

    countryValue *armyIn = getArmiesInCountry(country);

    if (armyIn->second > 0) {
        cout << "Destroyed army of " << *(player->name) << " in " << *(country->name) << endl;
        player->armyDestroyed(country);
        return true;
    }

    else {
        cout << "ERROR!! YOU Cannot destroy an army of another player.... ERROR:  player has no armies." << endl;
    }

    return false;

// must impliment And or aciton??
// andOrAction();


//below is the good score methods


void Player::printGoods() {
    int ruby = 0;
    int wood = 0;
    int carrot = 0;
    int anvil = 0;
    int ore = 0;
    int wild = 0;

    for (auto card : *hand) {
        switch (card->good.type) {
            case Good::GoodType::GOOD_RUBY :
                ruby += card->good.count;
                break;
            case Good::GoodType::GOOD_WOOD :
                wood += card->good.count;
                break;
            case Good::GoodType::GOOD_CARROT :
                carrot += card->good.count;
                break;
            case Good::GoodType::GOOD_ANVIL :
                anvil += card->good.count;
                break;
            case Good::GoodType::GOOD_ORE :
                ore += card->good.count;
                break;
            case Good::GoodType::GOOD_WILD :
                wild += card->good.count;
                break;
        }
    }

    cout << "\tYou have the following goods:" << endl;
    cout << "\tRuby: " << ruby << endl;
    cout << "\tWood: " << wood << endl;
    cout << "\tCarrot: " << carrot << endl;
    cout << "\tAnvil: " << anvil << endl;
    cout << "\tOre: " << ore << endl;
    cout << "\tWild: " << wild << endl;

}

void Player::computeTotalGoodScore() {
    int ruby = 0;
    int wood = 0;
    int carrot = 0;
    int anvil = 0;
    int ore = 0;
    int wild = 0;

    for (auto card : *hand) {
        switch (card->good.type) {
            case Good::GoodType::GOOD_RUBY :
                ruby += card->good.count;
                break;
            case Good::GoodType::GOOD_WOOD :
                wood += card->good.count;
                break;
            case Good::GoodType::GOOD_CARROT :
                carrot += card->good.count;
                break;
            case Good::GoodType::GOOD_ANVIL :
                anvil += card->good.count;
                break;
            case Good::GoodType::GOOD_ORE :
                ore += card->good.count;
                break;
            case Good::GoodType::GOOD_WILD :
                wild += card->good.count;
                break;
        }
    }

   if (wild > 0) {
        cout << endl;
        cout << *name << ", You have " << wild << " cards , please assign your cards " << endl;
        cout << "Goodlist: ruby, wood, carrot, anvil, ore" << endl;
        while (wild > 0) {
            string good;
            cout << "Enter a good type: ";
            cin >> good;

            if (good == "ruby") {
                ruby++;
                wild--;
            }

            if (good == "wood") {
                wood++;
                wild--;
            }

            if (good == "carrot") {
                carrot++;
                wild--;
            }

            if (good == "anvil") {
                anvil++;
                wild--;
            }

            if (good == "ore") {
                ore++;
                wild--;
            }
        }
    }

    switch (ruby) {
        case 0:
            break;
        case 1:
            (*score->goodScore) += 1;
            break;
        case 2:
            (*score->goodScore) += 2;
            break;
        case 3:
            (*score->goodScore) += 3;
            break;
        default: 
            (*score->goodScore) += 6;
    }

    switch (wood) {
        case 0:
            break;
        case 1:
        case 2:
            (*score->goodScore) += 1;
            break;
        case 3:
        case 4:
            (*score->goodScore) += 2;
            break;
        case 5:
            (*score->goodScore) += 3;
            break;
        default: 
            (*score->goodScore) += 6;

    }

    switch (carrot) {
        case 0:
            break;
        case 1:
        case 2:
        case 3:
            (*score->goodScore) += 1;
            break;
        case 4:
        case 5:
            (*score->goodScore) += 2;
            break;
        case 6:
        case 7:
            (*score->goodScore) += 3;
            break;
        default: 
            (*score->goodScore) += 6;

    }

    switch (anvil) {
        case 0:
            break;
        case 1:
        case 2:
            (*score->goodScore) += 1;
            break;
        case 3:
        case 4:
            (*score->goodScore) += 2;
            break;
        case 5:
        case 6:
            (*score->goodScore) += 3;
            break;
        default: 
            (*score->goodScore) += 6;
    }

    switch (ore) {
        case 0:
            break;
        case 1:
        case 2:
            (*score->goodScore) += 1;
            break;
        case 3:
            (*score->goodScore) += 2;
            break;
        case 4:
            (*score->goodScore) += 3;
            break;
        default: 
            (*score->goodScore) += 6;
    }
}






